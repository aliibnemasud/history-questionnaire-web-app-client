export let applyingPosition = ["Police Officer","Sheriff’s Deputy","Firefighter","Firefighter/EMT","Firefighter/EMS","Firefighter/Paramedic",
  "Paramedic","Corrections Officer","Corrections Deputy","Juvenile Corrections Officer","Dispatcher",
  "Call Taker","Records Specialist","Support Specialist","Chief of Police","Fire Chief","Deputy/Assistant Chief of Police",
  "Deputy/Assistant Fire Chief","Other"];

export let siblings = ["biological brother", "biological sister", "stepbrother", "stepsister", "half-brother", "half-sister"];

export let militaryBranch = ["U.S. Marine Corps","U.S. Navy","U.S. Army","U.S. Air Force","U.S. Coast Guard","U.S. Space Force","National Guard"];


